// Problem Link -
/*By Manjot Kaur*/
#include <bits/stdc++.h>
//#include<ext/pb_ds/assoc_container.hpp>
//#include<ext/pb_ds/tree_policy.hpp>
//#include <ext/pb_ds/trie_policy.hpp>
// using namespace __gnu_pbds;
using namespace std;
#define ll long long int
#define ld long double
#define mod 1000000007
#define inf 1e18
#define endl "\n"
#define pb push_back
#define vi vector<ll>
#define vs vector<string>
#define pii pair<ll, ll>
#define ump unordered_map
#define mp make_pair
#define pq_max priority_queue<ll>
#define pq_min priority_queue<ll, vi, greater<ll>>
#define all(n) n.begin(), n.end()
#define ff first
#define ss second
#define mid(l, r) (l + (r - l) / 2)
#define bitc(n) __builtin_popcount(n)
#define loop(i, a, b) for (int i = (a); i <= (b); i++)
#define looprev(i, a, b) for (int i = (a); i >= (b); i--)
#define iter(container, it) for (__typeof(container.begin()) it = container.begin(); it != container.end(); it++)
#define log(args...)                             \
	{                                            \
		string _s = #args;                       \
		replace(_s.begin(), _s.end(), ',', ' '); \
		stringstream _ss(_s);                    \
		istream_iterator<string> _it(_ss);       \
		err(_it, args);                          \
	}
#define logarr(arr, a, b)            \
	for (int z = (a); z <= (b); z++) \
		cout << (arr[z]) << " ";     \
	cout << endl;
template <typename T>
T gcd(T a, T b)
{
	if (a % b)
		return gcd(b, a % b);
	return b;
}
template <typename T>
T lcm(T a, T b) { return (a * (b / gcd(a, b))); }
vs tokenizer(string str, char ch)
{
	std::istringstream var((str));
	vs v;
	string t;
	while (getline((var), t, (ch)))
	{
		v.pb(t);
	}
	return v;
}

void err(istream_iterator<string> it) {}
template <typename T, typename... Args>
void err(istream_iterator<string> it, T a, Args... args)
{
	cout << *it << " = " << a << endl;
	err(++it, args...);
}
// typedef tree<ll, null_type, less<ll>, rb_tree_tag, tree_order_statistics_node_update> pbds;
// typedef trie<string,null_type,trie_string_access_traits<>,pat_trie_tag,trie_prefix_search_node_update> pbtrie;

void file_i_o()
{
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
#ifndef ONLINE_JUDGE
	freopen("/home/amninder/Desktop/hashcode/round1/hashcode2022/input_data/c.txt", "r", stdin);
	freopen("/home/amninder/Desktop/hashcode/round1/hashcode2022/input_data/dc.txt", "w", stdout);
#endif
}

class Project
{
public:
	string name;
	int a, b, c, d;
	vector<pair<string, int>> skills;
};

int main(int argc, char const *argv[])
{
	// clock_t begin = clock();
	// file_i_o();
	// // Write your code here....

	int c, p;
	cin >> c >> p;
	unordered_map<string, vector<pair<int, string>>> m;
	for (int i = 0; i < c; i++)
	{
		string name;
		int s;
		cin >> name >> s;
		for (int j = 0; j < s; j++)
		{
			string skill;
			int level;
			cin >> skill >> level;
			m[skill].push_back({level, name});
		}
	}
	vector<Project> proj(p);
	for (int i = 0; i < p; i++)
	{
		string name;
		int a, b, c, d;
		cin >> name >> a >> b >> c >> d;
		Project pi;
		pi.a = a;
		pi.b = b;
		pi.c = c;
		pi.d = d;
		pi.name = name;
		proj[i] = pi;
		for (int j = 0; j < d; j++)
		{
			string skill;
			int level;
			cin >> skill >> level;
			proj[i].skills.emplace_back(skill, level);
		}
	}
	vi arr(p, -1);
	vector<pair<string,int>> resP;
	vector<vector<string>> resC(p);
	while (true)
	{
		bool once = false;
		for (int j = 0; j < p; j++)
		{
			if(arr[j]==1) continue;
			Project pi = proj[j];
			vector<string> contrub;
			vector<int> ids;
			for (int i = 0; i < pi.skills.size(); i++)
			{
				if (m.count(pi.skills[i].first))
				{
					for (int k = 0; k < m[pi.skills[i].first].size(); k++)
					{
						auto l = m[pi.skills[i].first][k];
						if (l.ff >= pi.skills[i].second)
						{
							bool one = true;
							for(string n : contrub){
								if(n==l.ss) one = false;
							}
							if(one){
								ids.pb(k);
							contrub.pb(l.ss);
							break;
							} 
						}
					}
				}
			}
			if (contrub.size() == pi.skills.size())
			{
				for (int i = 0; i < pi.skills.size(); i++)
				{
					
					for (int k = 0; k < m[pi.skills[i].first].size(); k++)
					{
						auto l = m[pi.skills[i].first][k];
						if (l.ff >= pi.skills[i].second and k==ids[i])
						{
							if (l.ff == pi.skills[i].ss)
							{
								m[pi.skills[i].first][k].ff++;
							}
							break;
						}
					}
					
				}
				arr[j] = 1;
				once = true;
				int len = resP.size();
				resP.pb({pi.name,len});
				for (auto name : contrub)
				{
					resC[len].pb(name);
				}
			}
		}
		bool ok = true;
		for (int i = 0; i < p; i++)
		{
			if (arr[i] == -1)
				ok = false;
		}
		if (ok){
			break;
		}
		if (not once){
			break;
		}
	}
	cout<<resP.size()<<endl;
	for(int i=0; i<resP.size(); i++){
		cout<<resP[i].ff<<endl;
		for(int j=0; j<resC[i].size(); j++){
			cout<<resC[i][j]<<" ";
		}
		cout<<endl;
	}

	return 0;
}