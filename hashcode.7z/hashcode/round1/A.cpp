// Problem Link -
/*By Manjot Kaur*/
#include <bits/stdc++.h>
//#include<ext/pb_ds/assoc_container.hpp>
//#include<ext/pb_ds/tree_policy.hpp>
//#include <ext/pb_ds/trie_policy.hpp>
// using namespace __gnu_pbds;
using namespace std;
#define ll long long int
#define ld long double
#define mod 1000000007
#define inf 1e18
#define endl "\n"
#define pb push_back
#define vi vector<ll>
#define vs vector<string>
#define pii pair<ll, ll>
#define ump unordered_map
#define mp make_pair
#define pq_max priority_queue<ll>
#define pq_min priority_queue<ll, vi, greater<ll>>
#define all(n) n.begin(), n.end()
#define ff first
#define ss second
#define mid(l, r) (l + (r - l) / 2)
#define bitc(n) __builtin_popcount(n)
#define loop(i, a, b) for (int i = (a); i <= (b); i++)
#define looprev(i, a, b) for (int i = (a); i >= (b); i--)
#define iter(container, it) for (__typeof(container.begin()) it = container.begin(); it != container.end(); it++)
#define log(args...)                             \
	{                                            \
		string _s = #args;                       \
		replace(_s.begin(), _s.end(), ',', ' '); \
		stringstream _ss(_s);                    \
		istream_iterator<string> _it(_ss);       \
		err(_it, args);                          \
	}
#define logarr(arr, a, b)            \
	for (int z = (a); z <= (b); z++) \
		cout << (arr[z]) << " ";     \
	cout << endl;
template <typename T>
T gcd(T a, T b)
{
	if (a % b)
		return gcd(b, a % b);
	return b;
}
template <typename T>
T lcm(T a, T b) { return (a * (b / gcd(a, b))); }
vs tokenizer(string str, char ch)
{
	std::istringstream var((str));
	vs v;
	string t;
	while (getline((var), t, (ch)))
	{
		v.pb(t);
	}
	return v;
}

void err(istream_iterator<string> it) {}
template <typename T, typename... Args>
void err(istream_iterator<string> it, T a, Args... args)
{
	cout << *it << " = " << a << endl;
	err(++it, args...);
}
// typedef tree<ll, null_type, less<ll>, rb_tree_tag, tree_order_statistics_node_update> pbds;
// typedef trie<string,null_type,trie_string_access_traits<>,pat_trie_tag,trie_prefix_search_node_update> pbtrie;


class Project
{
public:
	string name;
	int a, b, c, d;
	vector<pair<string, int>> skills;
};

int main(int argc, char const *argv[])
{

	int c, p;
	cin >> c >> p;
	unordered_map<string, vector<pair<int, string>>> m;
	for (int i = 0; i < c; i++)
	{
		string name;
		int s;
		cin >> name >> s;
		for (int j = 0; j < s; j++)
		{
			string skill;
			int level;
			cin >> skill >> level;
			m[skill].push_back({level, name});
		}
	}
	vector<Project> proj(p);
	for (int i = 0; i < p; i++)
	{
		string name;
		int a, b, c, d;
		cin >> name >> a >> b >> c >> d;
		Project pi;
		pi.a = a;
		pi.b = b;
		pi.c = c;
		pi.d = d;
		pi.name = name;
		proj[i] = pi;
		for (int j = 0; j < d; j++)
		{
			string skill;
			int level;
			cin >> skill >> level;
			proj[i].skills.emplace_back(skill, level);
		}
	}
	vi arr(p, -1);
	cout<<p<<endl;
	while (true)
	{
		bool once = false;
		for (int j = 0; j < p; j++)
		{
			if(arr[j]==1) continue;
			Project pi = proj[j];
			vector<string> contrub;
			for (int i = 0; i < pi.skills.size(); i++)
			{
				if (m.count(pi.skills[i].first))
				{
					for (auto l : m[pi.skills[i].first])
					{
						if (l.ff >= pi.skills[i].second)
						{
							contrub.pb(l.ss);
							break;
						}
					}
				}
			}
			if (contrub.size() == pi.skills.size())
			{
				for (int i = 0; i < pi.skills.size(); i++)
				{
					
					for (int k = 0; k < m[pi.skills[i].first].size(); k++)
					{
						auto l = m[pi.skills[i].first][k];
						if (l.ff >= pi.skills[i].second)
						{
							if (l.ff == pi.skills[i].ss)
							{
								m[pi.skills[i].first][k].ff++;
							}
							break;
						}
					}
					
				}
				arr[j] = 1;
				once = true;
				cout<<pi.name<<endl;
				for (auto name : contrub)
				{
					cout << name << " ";
				}
				cout << endl;
			}
		}
		bool ok = true;
		for (int i = 0; i < p; i++)
		{
			if (arr[i] == -1)
				ok = false;
		}
		if (ok)
			break;
		if (not once)
			break;
	}

	return 0;
}