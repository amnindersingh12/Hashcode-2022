
class Contributor:
    def __init__(self, skills):
        self.skills = skills


class Project:
    def __init__(self, days, score, bbday, roles):
        self.days = days
        self.score = score
        self.bbday = bbday
        self.roles = roles

# reading input
# this is for parsing the input
def read_file(file_path):
    
        contributors = {}
        projects = {}
        eq_skills_to_contribs = {}
        geq_skills_to_contribs = {}
    
        with open(file_path, 'r') as f:
    
            project_and_contributors = list(
                map(int, f.readline().strip().split(' ')))
    
            n_contributors, n_projects = project_and_contributors[0], project_and_contributors[1]
    
            for i in range(n_contributors):
                name, n_skills = f.readline().strip().split(' ')
                n_skills = int(n_skills)
                
                currSkills = {}
    
                for j in range(n_skills):
    
                    skillName, skillLevel = f.readline().strip().split(' ')
    
                    skillLevel = int(skillLevel)
    
                    currSkills[skillName] = skillLevel
    
                    if skillName not in eq_skills_to_contribs:
                        eq_skills_to_contribs[skillName] = [[]
                                                            for _ in range(501)]
                    eq_skills_to_contribs[skillName][skillLevel].append(name)
    
                    if skillName not in geq_skills_to_contribs:
                        geq_skills_to_contribs[skillName] = [[]
                                                            for _ in range(501)]
                    for lvl in range(1, skillLevel + 1):
                        geq_skills_to_contribs[skillName][lvl].append(name)
    
                contributors[name] = Contributor(currSkills)
    
            for i in range(n_projects):
                name, days, score, bbday, n_roles = f.readline().strip().split(' ')
                days, score, bbday, n_roles = int(days), int(
                    score), int(bbday), int(n_roles)
    
                curr_roles = []
                
                for j in range(n_roles):
                    skillName, skillLevel = f.readline().strip().split(' ')
                    skillLevel = int(skillLevel)
                    curr_roles.append((skillName, skillLevel))
                projects[name] = Project(days, score, bbday, curr_roles)
        return contributors, projects, eq_skills_to_contribs, geq_skills_to_contribs


# for dummy testing score
def get_score(projects, print=0):
    score = 0
    for proj in projects:
        if projects[proj].contributors:  
            score += projects[proj].score
    return score

# will print result
def print_result(file_name, projects_done):
    with open(file_name, 'w') as f:
        f.write(f'{len(projects_done)}\n')
        for proj in projects_done:
            f.write(f'{list(proj.keys())[0]}\n')
            f.write(f'{" ".join(list(proj.values())[0])}\n')


def solve(projects):

    # projects = {'p1': Project(days=1, score=1, bbday=1, roles=[]),
    # curr_time is the current time
    curr_time = 0

    # projects_done is the list of projects that have been completed
    available = {}

    projects_done = []
    score = 0

    # availabe is a dictionary of projects that are available to be worked on
    # initially all projects are available
    for contrib_name in contributors:
        
        available[contrib_name] = 0


    
    for proj in projects:

        curr_contributors = []

        # if the project is not yet completed
        failed = False

        # each project has a list of contributors
        for role in projects[proj].roles:

            # if the contributor is available
            role_name = role[0]
            lvl = role[1]
            
            found = False
            
            for contrib_name in geq_skills_to_contribs[role_name][lvl]:
               
                # here, we are checking if atleast one contributor is available with minimum skills
                contrib_name = min([x for x in geq_skills_to_contribs[role_name][lvl] if x not in curr_contributors], key=lambda x: available[x], default=None)

                # if the contributor is available
                if contrib_name is not None:
                    found = True
                    curr_contributors.append(contrib_name)
                    
            # if no contributor is available with minimum skills
            if not found:
                failed = True
                break
        # if the project is not yet completed
        if not failed:

            # add the project to the list of completed projects
          
            start_day = curr_time
            for contrib_name in curr_contributors:
                available[contrib_name] = start_day + projects[proj].days
            if start_day + projects[proj].days >= projects[proj].score + projects[proj].bbday:
                continue
            for contrib_name in curr_contributors:
                available[contrib_name] = start_day + projects[proj].days
            score += projects[proj].score
            projects_done.append({proj: curr_contributors})

    return projects_done, score



input_file = '/home/amninder/Desktop/hashcode/round1/hashcode2022/input_data/d.txt'
contributors, projects, eq_skills_to_contribs, geq_skills_to_contribs = read_file(
    input_file)

projects_done, score = solve(projects)

print(score)

output_file = f'ddddc.txt'
print_result(output_file, projects_done)

